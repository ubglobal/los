<?php
// File: includes/footer.php
?>
        </div>
    </div>
</div>
</body>
</html>

